/*chrome.tabs.query({currentWindow: true, active: true}, function (tab) {
	if (tab[0].url.startsWith("https://youtube.com") ||tab[0].url.startsWith("https://www.youtube.com")) {
		chrome.tabs.update(tab[0].id, {url: tab[0].url+"&force_ad_encrypted=M44ZbxxbpoD7eujBOAcjwuaNMpzRjG6HEufbPOo4BiPyhNbHfIEnAyMRpoQbCg8gMZb-KXsGzRni08b009mvsB-iJIKXOluLzIIwph4F0baZQfMFG76okQPO5CXlsfPA0Wsyeo3VQhtkh3bjA2LvXdgA10gft0oAk0Jp2VSxMbx7DalaFDTMu8k7suDQ97-CCESYkIHtxF4vRqAVo-SCMqRHFlNkG6tySBqgVR6O9Gcwlk8DFETE2gUvv-WxN4ThctQd51jJ4wrGYVU-ULBMrbp1ah7xg_rABgvguB-6YmqvgQPwmP2vhx3fxdqr41HYQZOzi-204cxpIcuV4cpNHS0C8rFfNlvd3g9vTA1lUQlyRFTcPJKhK7pOFnx3XB-qaTrjoLSt5DT4iYyIGB1pMQOydTk2wfl-ktDrDMF7XlwZxcivL_po62QvODB1Mdpf7UV4reF299XohFfWV5AFpokPXdHLkXN6L8eD7XqIqs-aTHpreoSH0qUUMSkY67lrt3bYMfPwmZ41iLCkpy5XI_GGsyLZnB8AkIg6FEXIB-eRq0VKX1hxjfrM-2wWEMs497O8SOeoHWxHzwBCxaTHbG70Dfmox9gGoR4GsxhLebp-cizDlSDdPjKnDooUlvRrpaEvZ2pD4goIyn-0-dp1U10hN1fBIQW8oQ9T2GdVf-kWUQDNfQJOuKHugmCwZMJd3D-w2Esfjgc="});
	}
});*/

chrome.webNavigation.onCompleted.addListener(function(details) {
    chrome.tabs.query({currentWindow: true, active: true}, function (tab) {
		if (tab[0].url.includes("/watch")){
			if (!tab[0].url.includes("force_ad_encrypted")){
			chrome.tabs.update(tab[0].id, {url: tab[0].url+"&force_ad_encrypted=M44ZbxxbpoD7eujBOAcjwuaNMpzRjG6HEufbPOo4BiPyhNbHfIEnAyMRpoQbCg8gMZb-KXsGzRni08b009mvsB-iJIKXOluLzIIwph4F0baZQfMFG76okQPO5CXlsfPA0Wsyeo3VQhtkh3bjA2LvXdgA10gft0oAk0Jp2VSxMbx7DalaFDTMu8k7suDQ97-CCESYkIHtxF4vRqAVo-SCMqRHFlNkG6tySBqgVR6O9Gcwlk8DFETE2gUvv-WxN4ThctQd51jJ4wrGYVU-ULBMrbp1ah7xg_rABgvguB-6YmqvgQPwmP2vhx3fxdqr41HYQZOzi-204cxpIcuV4cpNHS0C8rFfNlvd3g9vTA1lUQlyRFTcPJKhK7pOFnx3XB-qaTrjoLSt5DT4iYyIGB1pMQOydTk2wfl-ktDrDMF7XlwZxcivL_po62QvODB1Mdpf7UV4reF299XohFfWV5AFpokPXdHLkXN6L8eD7XqIqs-aTHpreoSH0qUUMSkY67lrt3bYMfPwmZ41iLCkpy5XI_GGsyLZnB8AkIg6FEXIB-eRq0VKX1hxjfrM-2wWEMs497O8SOeoHWxHzwBCxaTHbG70Dfmox9gGoR4GsxhLebp-cizDlSDdPjKnDooUlvRrpaEvZ2pD4goIyn-0-dp1U10hN1fBIQW8oQ9T2GdVf-kWUQDNfQJOuKHugmCwZMJd3D-w2Esfjgc="});
		}}}); 
	
}, {
    url: [{
        // Runs on example.com, example.net, but also example.foo.com
        hostContains: '.youtube.'
    }],
});